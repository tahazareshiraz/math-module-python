# taha-math-shiraz

A pure-Python library that reimplements Python's built-in `math` module
(and the `statistics` module) completely from scratch, without relying on
`math` or `cmath` internally, plus a large collection of extra utilities:
number theory, linear algebra, geometry, calculus, interpolation,
probability distributions, base conversions, and more.

## Installation

```bash
pip install .
```

or simply copy the `taha_math_shiraz/` folder next to your project.

## Usage

```python
import taha_math_shiraz as tms

print(tms.PI)
print(tms.sqrt(2))
print(tms.sin(tms.PI / 2))
print(tms.factorial(10))
print(tms.is_prime(97))
print(tms.mean([1, 2, 3, 4, 5]))

m = tms.Matrix([[1, 2], [3, 4]])
print(m.determinant())
```

You can also import only what you need from a specific submodule:

```python
from taha_math_shiraz.trigonometry import sin, cos
from taha_math_shiraz.linalg import Vector, Matrix
from taha_math_shiraz.numbertheory import is_prime, fibonacci
```

## Package layout

```
taha_math_shiraz/
    __init__.py        re-exports the full public API
    constants.py        PI, E, TAU, INF, NAN, ...
    basics.py            fabs, floor, ceil, fmod, isnan, isinf, ...
    numtheory_core.py    factorial, gcd, lcm, isqrt
    power.py             sqrt, cbrt, pow_, exp, log, log2, log10, ...
    trigonometry.py      sin, cos, tan, asin, acos, atan, sinh, cosh, ...
    aggregates.py        fsum, prod, isclose, comb, perm
    special.py           gamma, lgamma, erf, erfc, frexp, ldexp, ...
    numbertheory.py      primes, divisors, totient, fibonacci, polygonal numbers, ...
    statistics_mod.py    mean, median, mode, variance, stdev, correlation, ...
    probability.py       binomial/normal/poisson/exponential distributions
    linalg.py            Vector, Matrix, Complex and related helpers
    combinatorics.py     permutations, combinations, partitions, bell numbers
    geometry.py          areas, volumes, distances, line intersection, ...
    calculus.py          derivative, integral, root-finding methods
    conversions.py       unit conversions (temperature, distance, mass)
    interpolation.py     Lagrange/Newton interpolation, continued fractions
    randomutil.py        a simple linear congruential generator
    baseconv.py          base conversion, Roman numerals
    series.py            arithmetic/geometric series sums
    activations.py       sigmoid, relu, clamp, lerp, smoothstep
    metrics.py           distRan rg --files
    ساختار پروژه را پیدا کردم: یک پکیج taha_math_shiraz با چندین ماژول عددی/ریاضی و یک مجموعه تست نسبتاً کامل. الان README و فایل‌های اصلی ورودی پکیج را می‌خوانم تا بفهمم API عمومی دقیقاً چیست و بعد سراغ ماژول‌های داخلی می‌روم.ance metrics, cosine similarity
```

## Tests

Tests live in the `tests/` folder and are split by topic, mirroring the
package layout. Run all of them with:

```bash
python -m unittest discover -s tests -v
```

```
math-module-tahazare
├─ README.md
├─ taha_math_shiraz
│  ├─ activations.py
│  ├─ aggregates.py
│  ├─ algorithms.py
│  ├─ baseconv.py
│  ├─ basics.py
│  ├─ calculus.py
│  ├─ combinatorics.py
│  ├─ constants.py
│  ├─ conversions.py
│  ├─ crypto.py
│  ├─ datatypes.py
│  ├─ geometry.py
│  ├─ graph.py
│  ├─ interpolation.py
│  ├─ linalg.py
│  ├─ metrics.py
│  ├─ numbertheory.py
│  ├─ numtheory_core.py
│  ├─ polynomial.py
│  ├─ power.py
│  ├─ probability.py
│  ├─ randomutil.py
│  ├─ series.py
│  ├─ special.py
│  ├─ statistics_mod.py
│  ├─ trigonometry.py
│  ├─ __init__.py
│  └─ __pycache__
│     ├─ activations.cpython-313.pyc
│     ├─ activations.cpython-314.pyc
│     ├─ aggregates.cpython-313.pyc
│     ├─ aggregates.cpython-314.pyc
│     ├─ algorithms.cpython-313.pyc
│     ├─ algorithms.cpython-314.pyc
│     ├─ baseconv.cpython-313.pyc
│     ├─ baseconv.cpython-314.pyc
│     ├─ basics.cpython-313.pyc
│     ├─ basics.cpython-314.pyc
│     ├─ calculus.cpython-313.pyc
│     ├─ calculus.cpython-314.pyc
│     ├─ combinatorics.cpython-313.pyc
│     ├─ combinatorics.cpython-314.pyc
│     ├─ constants.cpython-313.pyc
│     ├─ constants.cpython-314.pyc
│     ├─ conversions.cpython-313.pyc
│     ├─ conversions.cpython-314.pyc
│     ├─ crypto.cpython-313.pyc
│     ├─ crypto.cpython-314.pyc
│     ├─ datatypes.cpython-313.pyc
│     ├─ datatypes.cpython-314.pyc
│     ├─ geometry.cpython-313.pyc
│     ├─ geometry.cpython-314.pyc
│     ├─ graph.cpython-313.pyc
│     ├─ graph.cpython-314.pyc
│     ├─ interpolation.cpython-313.pyc
│     ├─ interpolation.cpython-314.pyc
│     ├─ linalg.cpython-313.pyc
│     ├─ linalg.cpython-314.pyc
│     ├─ metrics.cpython-313.pyc
│     ├─ metrics.cpython-314.pyc
│     ├─ numbertheory.cpython-313.pyc
│     ├─ numbertheory.cpython-314.pyc
│     ├─ numtheory_core.cpython-313.pyc
│     ├─ numtheory_core.cpython-314.pyc
│     ├─ polynomial.cpython-313.pyc
│     ├─ polynomial.cpython-314.pyc
│     ├─ power.cpython-313.pyc
│     ├─ power.cpython-314.pyc
│     ├─ probability.cpython-313.pyc
│     ├─ probability.cpython-314.pyc
│     ├─ randomutil.cpython-313.pyc
│     ├─ randomutil.cpython-314.pyc
│     ├─ series.cpython-313.pyc
│     ├─ series.cpython-314.pyc
│     ├─ special.cpython-313.pyc
│     ├─ special.cpython-314.pyc
│     ├─ statistics_mod.cpython-313.pyc
│     ├─ statistics_mod.cpython-314.pyc
│     ├─ trigonometry.cpython-313.pyc
│     ├─ trigonometry.cpython-314.pyc
│     ├─ __init__.cpython-313.pyc
│     └─ __init__.cpython-314.pyc
├─ temp.py
└─ tests
   ├─ test_activations.py
   ├─ test_basics.py
   ├─ test_calculus.py
   ├─ test_constants.py
   ├─ test_geometry.py
   ├─ test_interpolation_conversion.py
   ├─ test_legacy_self_checks.py
   ├─ test_linalg.py
   ├─ test_new_modules.py
   ├─ test_numbertheory.py
   ├─ test_power.py
   ├─ test_special.py
   ├─ test_statistics.py
   ├─ test_trigonometry.py
   └─ __init__.py

```
```
math-module-tahazare
├─ .agents
├─ dist
│  ├─ taha_math_shiraz-1.1.0-py3-none-any.whl
│  └─ taha_math_shiraz-1.1.0.tar.gz
├─ docs
│  ├─ document.html
│  ├─ document_english.html
│  ├─ generated_outputs.json
│  ├─ language.html
│  ├─ math-module-logo.png
│  ├─ style_English.css
│  └─ style_persian.css
├─ pyproject.toml
├─ README.md
├─ src
│  ├─ taha_math_shiraz
│  │  ├─ activations.py
│  │  ├─ aggregates.py
│  │  ├─ algorithms.py
│  │  ├─ baseconv.py
│  │  ├─ basics.py
│  │  ├─ calculus.py
│  │  ├─ combinatorics.py
│  │  ├─ constants.py
│  │  ├─ conversions.py
│  │  ├─ crypto.py
│  │  ├─ datatypes.py
│  │  ├─ geometry.py
│  │  ├─ graph.py
│  │  ├─ interpolation.py
│  │  ├─ linalg.py
│  │  ├─ metrics.py
│  │  ├─ numbertheory.py
│  │  ├─ numtheory_core.py
│  │  ├─ polynomial.py
│  │  ├─ power.py
│  │  ├─ probability.py
│  │  ├─ randomutil.py
│  │  ├─ series.py
│  │  ├─ special.py
│  │  ├─ statistics_mod.py
│  │  ├─ trigonometry.py
│  │  ├─ __init__.py
│  │  └─ __pycache__
│  │     ├─ activations.cpython-314.pyc
│  │     ├─ aggregates.cpython-314.pyc
│  │     ├─ algorithms.cpython-314.pyc
│  │     ├─ baseconv.cpython-314.pyc
│  │     ├─ basics.cpython-314.pyc
│  │     ├─ calculus.cpython-314.pyc
│  │     ├─ combinatorics.cpython-314.pyc
│  │     ├─ constants.cpython-314.pyc
│  │     ├─ conversions.cpython-314.pyc
│  │     ├─ crypto.cpython-314.pyc
│  │     ├─ datatypes.cpython-314.pyc
│  │     ├─ geometry.cpython-314.pyc
│  │     ├─ graph.cpython-314.pyc
│  │     ├─ interpolation.cpython-314.pyc
│  │     ├─ linalg.cpython-314.pyc
│  │     ├─ metrics.cpython-314.pyc
│  │     ├─ numbertheory.cpython-314.pyc
│  │     ├─ numtheory_core.cpython-314.pyc
│  │     ├─ polynomial.cpython-314.pyc
│  │     ├─ power.cpython-314.pyc
│  │     ├─ probability.cpython-314.pyc
│  │     ├─ randomutil.cpython-314.pyc
│  │     ├─ series.cpython-314.pyc
│  │     ├─ special.cpython-314.pyc
│  │     ├─ statistics_mod.cpython-314.pyc
│  │     ├─ trigonometry.cpython-314.pyc
│  │     └─ __init__.cpython-314.pyc
│  ├─ __init__.py
│  └─ __pycache__
│     └─ __init__.cpython-314.pyc
├─ taha_math_shiraz
│  ├─ __init__.py
│  └─ __pycache__
│     ├─ activations.cpython-313.pyc
│     ├─ activations.cpython-314.pyc
│     ├─ aggregates.cpython-313.pyc
│     ├─ aggregates.cpython-314.pyc
│     ├─ algorithms.cpython-313.pyc
│     ├─ algorithms.cpython-314.pyc
│     ├─ baseconv.cpython-313.pyc
│     ├─ baseconv.cpython-314.pyc
│     ├─ basics.cpython-313.pyc
│     ├─ basics.cpython-314.pyc
│     ├─ calculus.cpython-313.pyc
│     ├─ calculus.cpython-314.pyc
│     ├─ combinatorics.cpython-313.pyc
│     ├─ combinatorics.cpython-314.pyc
│     ├─ constants.cpython-313.pyc
│     ├─ constants.cpython-314.pyc
│     ├─ conversions.cpython-313.pyc
│     ├─ conversions.cpython-314.pyc
│     ├─ crypto.cpython-313.pyc
│     ├─ crypto.cpython-314.pyc
│     ├─ datatypes.cpython-313.pyc
│     ├─ datatypes.cpython-314.pyc
│     ├─ geometry.cpython-313.pyc
│     ├─ geometry.cpython-314.pyc
│     ├─ graph.cpython-313.pyc
│     ├─ graph.cpython-314.pyc
│     ├─ interpolation.cpython-313.pyc
│     ├─ interpolation.cpython-314.pyc
│     ├─ linalg.cpython-313.pyc
│     ├─ linalg.cpython-314.pyc
│     ├─ metrics.cpython-313.pyc
│     ├─ metrics.cpython-314.pyc
│     ├─ numbertheory.cpython-313.pyc
│     ├─ numbertheory.cpython-314.pyc
│     ├─ numtheory_core.cpython-313.pyc
│     ├─ numtheory_core.cpython-314.pyc
│     ├─ polynomial.cpython-313.pyc
│     ├─ polynomial.cpython-314.pyc
│     ├─ power.cpython-313.pyc
│     ├─ power.cpython-314.pyc
│     ├─ probability.cpython-313.pyc
│     ├─ probability.cpython-314.pyc
│     ├─ randomutil.cpython-313.pyc
│     ├─ randomutil.cpython-314.pyc
│     ├─ series.cpython-313.pyc
│     ├─ series.cpython-314.pyc
│     ├─ special.cpython-313.pyc
│     ├─ special.cpython-314.pyc
│     ├─ statistics_mod.cpython-313.pyc
│     ├─ statistics_mod.cpython-314.pyc
│     ├─ trigonometry.cpython-313.pyc
│     ├─ trigonometry.cpython-314.pyc
│     ├─ __init__.cpython-313.pyc
│     └─ __init__.cpython-314.pyc
├─ taha_math_shiraz.egg-info
│  ├─ dependency_links.txt
│  ├─ PKG-INFO
│  ├─ SOURCES.txt
│  └─ top_level.txt
├─ temp.py
└─ tests
   ├─ test_activations.py
   ├─ test_basics.py
   ├─ test_calculus.py
   ├─ test_constants.py
   ├─ test_geometry.py
   ├─ test_interpolation_conversion.py
   ├─ test_legacy_self_checks.py
   ├─ test_linalg.py
   ├─ test_new_modules.py
   ├─ test_numbertheory.py
   ├─ test_power.py
   ├─ test_special.py
   ├─ test_statistics.py
   ├─ test_trigonometry.py
   ├─ __init__.py
   └─ __pycache__
      ├─ test_activations.cpython-314.pyc
      ├─ test_basics.cpython-314.pyc
      ├─ test_calculus.cpython-314.pyc
      ├─ test_constants.cpython-314.pyc
      ├─ test_geometry.cpython-314.pyc
      ├─ test_interpolation_conversion.cpython-314.pyc
      ├─ test_legacy_self_checks.cpython-314.pyc
      ├─ test_linalg.cpython-314.pyc
      ├─ test_new_modules.cpython-314.pyc
      ├─ test_numbertheory.cpython-314.pyc
      ├─ test_power.cpython-314.pyc
      ├─ test_special.cpython-314.pyc
      ├─ test_statistics.cpython-314.pyc
      └─ test_trigonometry.cpython-314.pyc

```